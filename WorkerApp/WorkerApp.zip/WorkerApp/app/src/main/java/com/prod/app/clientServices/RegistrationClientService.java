package com.prod.app.clientServices;

import com.prod.app.Interfaces.IClientServices;
import com.prod.app.protobuff.Registration;

public class RegistrationClientService implements IClientServices<Registration.RegistrationRequestPb, Registration.RegistrationResponsePb,Registration.RegistrationResponsePb> {
    @Override
    public Registration.RegistrationResponsePb getCall(Registration.RegistrationRequestPb request, Class<Registration.RegistrationResponsePb> clazz) {
        return null;
    }
}
