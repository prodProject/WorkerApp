package com.prod.app.Interfaces;

import com.google.protobuf.GeneratedMessageV3;

public interface IClientServices<Req extends GeneratedMessageV3, Resp extends GeneratedMessageV3, T> {
    public Resp getCall(Req request, Class<T> clazz);
}
